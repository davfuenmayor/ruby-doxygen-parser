class DoxyVariable < DoxyMember
   
end