class DoxyTypedef < DoxyMember
   
end